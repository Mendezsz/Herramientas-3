﻿using Festivo.Entidades;
using Microsoft.EntityFrameworkCore;

namespace Festivo.Infraestructura.Persistencia.Contexto
{
    public class FestivoContext : DbContext
    {
        public FestivoContext(DbContextOptions<FestivoContext> options) : base(options)
        {
        }

        public DbSet<FestivoApp> Festivos { get; set; }
        public DbSet<Tipo> Tipos { get; set; }
    }
}
