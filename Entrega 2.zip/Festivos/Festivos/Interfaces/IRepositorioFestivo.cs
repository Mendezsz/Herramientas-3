﻿using Festivo.Entidades;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Festivo.Interfaces
{
    public interface IRepositorioFestivo
    {
        Task<IEnumerable<FestivoApp>> ObtenerTodosAsync();
        Task<FestivoApp> ObtenerPorIdAsync(int id);
        Task AgregarAsync(FestivoApp festivo);
        Task ActualizarAsync(FestivoApp festivo);
        Task EliminarAsync(int id);
    }
}
