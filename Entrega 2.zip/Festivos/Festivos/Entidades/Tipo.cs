﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Festivo.Entidades
{
    [Table("Tipo")]
    public class Tipo
    {
        [Column("Id")]
        public int Id { get; set; }

        [Column("Tipo")]
        public required string Nombre { get; set; }
    }
}
