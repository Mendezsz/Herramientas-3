﻿using Festivo.Entidades;
using Festivo.Infraestructura.Persistencia.Contexto;
using Festivo.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Festivo.Infraestructura.Persistencia.Repositorios
{
    public class RepositorioFestivo : IRepositorioFestivo
    {
        private readonly FestivoContext _contexto;

        public RepositorioFestivo(FestivoContext contexto)
        {
            _contexto = contexto;
        }

        public async Task<IEnumerable<FestivoApp>> ObtenerTodosAsync()
        {
            return await _contexto.Festivos
                .Include(f => f.Tipo)
                .ToListAsync();
        }

        public async Task<FestivoApp> ObtenerPorIdAsync(int id)
        {
            return await _contexto.Festivos
                .Include(f => f.Tipo)
                .FirstOrDefaultAsync(f => f.Id == id);
        }

        public async Task AgregarAsync(FestivoApp festivo)
        {
            await _contexto.Festivos.AddAsync(festivo);
            await _contexto.SaveChangesAsync();
        }

        public async Task ActualizarAsync(FestivoApp festivo)
        {
            _contexto.Festivos.Update(festivo);
            await _contexto.SaveChangesAsync();
        }

        public async Task EliminarAsync(int id)
        {
            var festivo = await ObtenerPorIdAsync(id);
            if (festivo != null)
            {
                _contexto.Festivos.Remove(festivo);
                await _contexto.SaveChangesAsync();
            }
        }
    }
}

