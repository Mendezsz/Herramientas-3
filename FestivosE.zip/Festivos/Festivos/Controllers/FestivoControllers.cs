using Festivo.Entidades;
using Festivo.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace Festivo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FestivoController : ControllerBase
    {
        private readonly IRepositorioFestivo _repositorio;

        public FestivoController(IRepositorioFestivo repositorio)
        {
            _repositorio = repositorio;
        }

        // GET: api/festivo
        [HttpGet]
        public async Task<IActionResult> ObtenerFestivos()
        {
            var festivos = await _repositorio.ObtenerTodosAsync();
            return Ok(festivos);
        }

        // GET: api/festivo/validar/mes/12/dia/25
        [HttpGet("validar/mes/{mes}/dia/{dia}")]
        public async Task<IActionResult> ValidarFestivo(int mes, int dia)
        {
            if (mes < 1 || mes > 12)
                return BadRequest("El mes debe estar entre 1 y 12.");

            if (dia < 1 || dia > 31)
                return BadRequest("El día debe estar entre 1 y 31.");

            var festivos = await _repositorio.ObtenerTodosAsync();
            var esFestivo = festivos.Any(f => f.Mes == mes && f.Dia == dia);

            return Ok(new
            {
                Mes = mes,
                Dia = dia,
                EsFestivo = esFestivo
            });
        }

        // POST: api/festivo
        [HttpPost]
        public async Task<IActionResult> CrearFestivo([FromBody] FestivoApp festivo)
        {
            if (festivo == null)
                return BadRequest("El objeto festivo no puede ser nulo.");

            if (string.IsNullOrEmpty(festivo.Nombre))
                return BadRequest("El nombre del festivo es obligatorio.");

            if (festivo.Mes < 1 || festivo.Mes > 12)
                return BadRequest("Mes inválido. Debe estar entre 1 y 12.");

            if (festivo.Dia < 1 || festivo.Dia > 31)
                return BadRequest("Día inválido. Debe estar entre 1 y 31.");

            try
            {
                await _repositorio.AgregarAsync(festivo);
                return CreatedAtAction(nameof(ObtenerFestivos), new { id = festivo.Id }, festivo);
            }
            catch (System.Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }
    }
}