﻿using Festivo.Entidades;
using Microsoft.EntityFrameworkCore;

namespace Festivo.Infrastructura.Persistencia.Contexto
{
    public class FestivoContext : DbContext
    {
        public FestivoContext(DbContextOptions<FestivoContext> options) : base(options)
        {
        }

        public DbSet<Festivo.Entidades.Festivo> Festivos { get; set; }
        public DbSet<Festivo.Entidades.Tipo> Tipos { get; set; }

    }
}


